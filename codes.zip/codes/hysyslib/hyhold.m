function hyhold(ApplicationObject)
% HYSTOP Hold calculations in Hysys
%    hyhold(ApplicationObject) holds the solver in Hysys.
%
%    Copyright (C) 1999 Olaf Trygve Berglihn <olafb@pvv.org>
%    Please read the files license.txt and lgpl.txt

%% $Id: hyhold.m,v 1.3 1999/04/20 08:52:52 olafb Exp $
%% ----------
%% Changelog:
%%
%% $Log: hyhold.m,v $
%% Revision 1.3  1999/04/20 08:52:52  olafb
%% The library is now under LGPL license.
%%
%% Revision 1.2  1999/04/07 11:59:31  olafb
%% *** empty log message ***
%%
%% Revision 1.1  1999/04/07 11:59:11  olafb
%% Initial revision
%%

hysolver = ApplicationObject.ActiveDocument.Solver;
hysolver.CanSolve = 0;

