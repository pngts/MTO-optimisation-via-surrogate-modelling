% Hysyslib toolbox - for using Matlab as an activeX/COM controller for Hysys.
% Copyright (C) 1999 Olaf Trygve Berglihn <olafb@pvv.org>

% $Id: Contents.m,v 1.5 1999/04/20 08:52:51 olafb Exp $
% $Revision: 1.5 $
%
%
% hyconnect      - Connect to Hysys application as a activeX controller.
% hyspread       - Connect to Hysys spreadsheet.
% hycell         - Connect to Hysys spreadsheet cell.
% hyvalue        - Get value of Hysys spreadsheet cell.
% hyunits        - Get the string specifying the units of a spreadsheet cell.
% hyset          - Change value of cell in Hysys spreadsheet.
% hyhold         - Set Hysys solver in hold mode.
% hystart        - Set Hysys solver in solve mode.
% hyissolving    - Check if solver is running.
