function hyrelease(ApplicationObject)
% HYRELEASE Release Hysys activex object

%    Copyright (C) 2008- Olaf Trygve Berglihn <olafb@pvv.org>
%    Please read the files license.txt and lgpl.txt

release(ApplicationObject);
