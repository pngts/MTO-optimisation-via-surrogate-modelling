function hystart(ApplicationObject)
% HYSTART Start the calculations in Hysys
%    hystart(ApplicationObject) turn on solving of Hysys spreadsheet.
%
%    Copyright (C) 1999 Olaf Trygve Berglihn <olafb@pvv.org>
%    Please read the files license.txt and lgpl.txt

%% $Id: hystart.m,v 1.2 1999/04/20 08:52:53 olafb Exp $
%% ----------
%% Changelog:
%%
%% $Log: hystart.m,v $
%% Revision 1.2  1999/04/20 08:52:53  olafb
%% The library is now under LGPL license.
%%
%% Revision 1.1  1999/04/07 12:02:35  olafb
%% Initial revision
%%
%%



hysolver = ApplicationObject.ActiveDocument.Solver;
hysolver.CanSolve = 1;

