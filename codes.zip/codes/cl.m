clc
clear
