classdef pinch < handle
    properties
        pinchFigure = {};
        pinchButton = {};
        coldTable = {};
        coldText = {};
        hotTable = {}; 
        hotText = {};
        pinchAxes = {};
        grandAxes = {};
        minBox = {};
        minText = {};
        minPlus = {};
        minMinus = {};
        hotStreams = {};
        coldStreams = {};
        hotBreaks = [];
        coldBreaks = [];
        hotEnergies = [];
        coldEnergies = [];
        allBreaks = [];
        allEnergies = [];
        allHeats = [];
        allColds = [];
        cascade = [];
        hotCoordinates = [];
        coldCoordinates = [];
        coldDuty = [];
        hotDuty = [];
        phaseText = [];
    end
    methods   
        function obj = pinch()
            % build the GUI
            obj.pinchFigure = figure('name','pinch analysis',...
                                            'numbertitle','off',...
                                            'ToolBar','none',...
                                            'MenuBar','None',...
                                            'Units','pixels',...
                                            'Position',[100 100 1000 420],...
                                            'Resize','off');            
            obj.hotTable = uitable('Parent',obj.pinchFigure,...
                                            'Units','normalized',...
                                            'Data',[ 40 250 1 0.15
                                                     80 200 1 0.25
                                                      0   0 0    0
                                                      0   0 0    0
                                                      0   0 0    0
                                                      0   0 0    0
                                                      0   0 0    0
                                                      0   0 0    0
                                                      0   0 0    0
                                                     ],...
                                                  'ColumnEditable',[true true true true true],...
                                                  'Position',[30/1000 240/420 285/1000 140/420],...
                                                  'RowName',{'1','2','3','4','5','6','7','8','9'},...
                                                  'ColumnName',{'Tlow','Thigh','flowrate','"heat of change"'},...
                                                  'ColumnWidth',{40,40,60,95});            
            obj.coldTable = uitable('Parent',obj.pinchFigure,...
                                            'Units','normalized',...
                                            'Data',[ 20 180 1 0.2
                                                    140 230 1 0.3
                                                      0   0 0    0
                                                      0   0 0    0
                                                      0   0 0    0
                                                      0   0 0    0
                                                      0   0 0    0
                                                      0   0 0    0
                                                      0   0 0    0
                                                     ],...
                                                  'ColumnEditable',[true true true true true],...
                                                  'Position',[30/1000 60/420 285/1000 140/420],...
                                                  'RowName',{'1','2','3','4','5','6','7','8','9'},...
                                                  'ColumnName',{'Tlow','Thigh','flowrate','"heat of change"'},...
                                                  'ColumnWidth',{40,40,60,95});
            obj.hotText = annotation('textbox',...
                                     'String','hot streams only (streams to cool)',...
                                     'Position',[30/1000 380/420 250/1000 25/420],...
                                     'Units','normalized',...                                    
                                     'EdgeColor',0.9411*[1 1 1]);
            obj.coldText = annotation('textbox',...
                                      'String','cold streams only (streams to heat)',...
                                      'Position',[30/1000 200/420 250/1000 25/420],...
                                      'Units','normalized',...                                    
                                      'EdgeColor',0.9411*[1 1 1]);
           obj.pinchButton = uicontrol('Style','pushbutton',...
                                       'Units','normalized',...
                                       'Position',[30/1000 10/420 60/1000 27/420],...
                                       'String','pinch',...
                                       'Callback',@(src,evt)pinchCallback(obj,src,evt),...
                                       'BusyAction','cancel', 'Interruptible','off');
           obj.minBox = uicontrol('Style','edit',...
                                  'Units','normalized',...
                                  'Position',[95/1000 10/420 60/1000 27/420],...
                                  'String',num2str(0),...
                                  'Callback',@(src,evt)boxCallback(obj,src,evt),...
                                  'BusyAction','cancel', 'Interruptible','off');
           obj.minPlus = uicontrol('Style','pushbutton',...
                                           'Units','normalized',...
                                           'Position',[160/1000 10/420 27/1000 27/420],...
                                           'String','+',...
                                           'Callback',@(src,evt)minP(obj,src,evt),...
                                           'BusyAction','cancel', 'Interruptible','off');
           obj.minMinus = uicontrol('Style','pushbutton',...
                                            'Units','normalized',...
                                            'Position',[190/1000 10/420 27/1000 27/420],...
                                            'String','-',...
                                            'Callback',@(src,evt)minM(obj,src,evt),...
                                            'BusyAction','cancel', 'Interruptible','off');  
            obj.minText = annotation('textbox',...
                                      'String','Tmin',...
                                      'Position',[103/1000 32/420 50/1000 25/420],...
                                      'Units','normalized',...                                    
                                      'EdgeColor',0.9411*[1 1 1]);
            obj.pinchAxes = axes('Units','normalized',...
                                 'Position',[380/1000 75/420 320/1000 320/420],...
                                 'Parent',obj.pinchFigure);
            obj.grandAxes = axes('Units','normalized',...
                                 'Position',[780/1000 75/420 180/1000 320/420],...
                                 'Parent',obj.pinchFigure);
            obj.phaseText = annotation('textbox',...
                                       'String','aggregate all phase change streams at a given temperature',...
                                       'Position',[480/1000 15/420 400/1000 25/420],...
                                       'Units','normalized',...                                    
                                       'EdgeColor',0.9411*[1 1 1]);
        end
        % populateStreams converts tables into stream objects
        % obj         = this pinch object
        %                 2nd output is the composite curve less phase chges
        % tableIn     = a uitable
        % streamCells = a cell array of stream objects to populate
        % hot         = -1 if hot streams to cool or 1 if cold streams to heat
        % breaks      = temperature discontinuities on the composite curve
        %               breaks lacks repeated temperatures of phase changes
        function [streamCells breaks] = populateStrms(obj,tableIn,streamCells,hot)
            breaks = [];          % we do not know how long breaks will be!
            streams = tableIn.Data;
            n = 1;
            % make streams from table and collect the breakpoints
            for i = 1:9
               if sum(streams(i,:)) ~= 0
                   streamCells{i} = stream(streams(i,:),hot);
                   breaks(n,1) = streams(i,1); % cannot readily preallocate
                   n = n+1;
                   breaks(n,1) = streams(i,2); % cannot readily preallocate
                   n = n+1;
               end
            end
            breaks = sort(breaks);
            % cull redundant breakpoints
            breaks = unique(breaks);            
        end
        % addPhaseChgs puts phase changes into the composite curve, where:
        % obj         = this pinch object
        % breaks      = temperature discontinuities on the composite curve
        % streamCells = a cell array of stream objects
        % Thalve      = half the absolute pinch distance, if relevant 
        function breaks = addPhaseChgs(obj,breaks,streamCells,Thalve)
            for i = 1:length(streamCells)
                if streamCells{i}.phase
                    loc = find( breaks == (streamCells{i}.Tlo + Thalve) );
                    breaks = [ breaks(1:loc,1)
                               streamCells{i}.Tlo+Thalve
                               breaks(loc+1:end,1)
                              ];
                end
            end            
        end
        % getEnergies calculates all power along a composite curve
        % obj         = this pinch object
        % breaks      = temperature discontinuities on the composite curve  
        % streamCells = a cell array of stream objects
        % Thalve      = half the absolute pinch distance, if relevant 
        function energies = getEnergies(obj,breaks,streamCells,Thalve)
            energies = zeros(length(breaks),1);           % preallocated
            for i = 2:length(breaks)
                energy = 0;
                for j = 1:length(streamCells)
                   energy = energy + ...
                            demand(streamCells{j},...
                                   [breaks(i-1) breaks(i)],...
                                   Thalve);
                end
                energies(i,1) = energy;  
            end
        end
        function resetContainers(obj)
            obj.hotStreams = {};
            obj.coldStreams = {};
            obj.hotBreaks = [];
            obj.coldBreaks = [];
            obj.hotEnergies = [];
            obj.coldEnergies = [];
            obj.allBreaks = [];
            obj.allEnergies = [];
            obj.allHeats = [];
            obj.allColds = [];
            obj.cascade = [];
            obj.hotCoordinates = [];
            obj.coldCoordinates = [];
            obj.coldDuty = [];
            obj.hotDuty = [];
        end
        function minP(obj,src,evt)
           obj.minBox.String = num2str( str2num(obj.minBox.String) + 1);
           pinchCallback(obj,src,evt);
        end
        function minM(obj,src,evt)
           obj.minBox.String = num2str( str2num(obj.minBox.String) - 1);
           pinchCallback(obj,src,evt);
        end
        function accumulated = accumulate(obj,array)
            accumulated = zeros(length(array),1);
            for i = 2:length(array)
               accumulated(i,1) = sum( array(1:i) ); 
            end
        end
        function boxCallback(obj,src,evt)
            pinchCallback(obj,src,evt);
        end
        % clean deletes extra elements phase chg can add to composite curve
        % obj = this pinch object
        % array = array to clean
        function array = clean(obj,array)
            % 2  redundant temperatures is indicative of phase change
            % 2+ redundant temperatures is nonsensical
            % cull any 2+ redundant temperatures...
            for i = 1:length(array)
                found = find( array == array(i) );
                if length(found) > 2
                   array( found(1) ) = NaN; 
                end
            end
            array = array( ~isnan(array) );        
        end
        function pinchCallback(obj,src,evt)
            resetContainers(obj);
        
            % composite curve for hot streams
            [obj.hotStreams obj.hotBreaks] = populateStrms(obj,obj.hotTable,obj.hotStreams,-1);
            % reinstate breaks for phase changes
            obj.hotBreaks = addPhaseChgs(obj,obj.hotBreaks,obj.hotStreams,0);
            % get the energy drop on each cooling interval along hot stream
            obj.hotEnergies = abs( getEnergies(obj,obj.hotBreaks,obj.hotStreams,0) );

            obj.hotCoordinates = accumulate(obj,obj.hotEnergies);
            
            % composite curve for cold streams
            [obj.coldStreams obj.coldBreaks] = populateStrms(obj,obj.coldTable,obj.coldStreams,1);
            % reinstate breaks for phase changes
            obj.coldBreaks = addPhaseChgs(obj,obj.coldBreaks,obj.coldStreams,0);
            % get the energy gain on each heating interval along cold stream
            obj.coldEnergies = getEnergies(obj,obj.coldBreaks,obj.coldStreams,0);

            obj.coldCoordinates = accumulate(obj,obj.coldEnergies);
            
            Thalve = str2num(obj.minBox.String)/2;
            
            % allBreaks is for grand composite curve (with Thalve shifts)
            obj.allBreaks = [ obj.coldBreaks+Thalve
                              obj.hotBreaks-Thalve ];
            obj.allBreaks = sort(obj.allBreaks);
            obj.allBreaks = unique(obj.allBreaks);  % cull redundant breaks
            
            % reinstate breaks for stream phase changes
            obj.allBreaks = addPhaseChgs(obj,obj.allBreaks,obj.coldStreams,Thalve);  
            obj.allBreaks = addPhaseChgs(obj,obj.allBreaks,obj.hotStreams,-Thalve);  
            obj.allBreaks = clean(obj,obj.allBreaks);   % cleanup allBreaks

            obj.allHeats = getEnergies(obj,obj.allBreaks,obj.hotStreams,-Thalve);
            obj.allColds = getEnergies(obj,obj.allBreaks,obj.coldStreams, Thalve);
            
            % energy surpluses and deficits
            obj.allEnergies = -(obj.allHeats + obj.allColds);
            
            % cascade from the hottest temperature
            obj.allEnergies = [obj.allEnergies(2:end)
                               obj.allEnergies(1)
                               ];
            obj.allEnergies = flipud(obj.allEnergies);
            obj.cascade = accumulate(obj,obj.allEnergies);
            obj.hotDuty = -min(obj.cascade);
            obj.cascade = obj.cascade + obj.hotDuty;
            
            obj.coldDuty = obj.cascade(end);
            obj.coldEnergies = obj.coldEnergies + obj.coldDuty;
            cla(obj.pinchAxes);
            axes(obj.pinchAxes);
            plot(obj.hotCoordinates,obj.hotBreaks);
            hold on;
            plot(obj.hotCoordinates,obj.hotBreaks-Thalve,'--');
            plot(obj.coldCoordinates+obj.coldDuty,obj.coldBreaks);
            plot(obj.coldCoordinates+obj.coldDuty,obj.coldBreaks+Thalve,'--');
            text(0.025,0.05,['cool ',num2str(obj.coldDuty)],'Units','normalized');
            text(0.8,.97,['heat ',num2str(obj.hotDuty)],'Units','normalized');
            cla(obj.grandAxes);
            axes(obj.grandAxes);
            plot(flipud(obj.cascade),obj.allBreaks);
        end
    end
end