% built for CHEN 4570 (CU Boulder) by Scott Rowe, all rights reserved
classdef stream < handle
    properties
        Tlo  = {};    % lowest  stream temperature "K"
        Thi  = {};    % highest stream temperature "K"
        flow = {};    % material flow ( "mol/sec" )
        heat = {};    % specific heat ( "J/(mol*K)" ) 
                      % or enthalpy of change ( "J/mol" )
        CP   = {};    % heat flowrate ( "J/sec*K" ) or ( "J/sec" )
        phase = [];
        hot = [];
    end
    methods     
        % inputs = [ Tlo Thi flow heat] 
        % hot = -1 if hot stream, +1 if cold stream 
        function obj = stream(inputs,hot)
           obj.Tlo  = inputs(1); 
           obj.Thi  = inputs(2); 
           if inputs(1) > inputs(2)
                obj.Tlo  = inputs(2); 
                obj.Thi  = inputs(1);                
           end
           obj.flow = abs(inputs(3));     % coerce absolute flows 
           obj.heat = abs(inputs(4));     % coerce absolute energies
           obj.CP = obj.flow*obj.heat;
           obj.phase = 0;
           if obj.Tlo == obj.Thi
               obj.phase = 1;
           end
           obj.hot = hot;
        end
        % return H, source/sink from stream on an arbitrary temperature interval
        % temps = [Tlower Tupper], extrenum of interval
        % Tshift = negative # for hots, positive # for colds
        %          absolute magnitude is halve the pinch temperature
        function H = demand(obj,Ts,Tshift)
            H = 0;
            if nargin == 3
                Ts = Ts - Tshift;                              % unshift Ts
                H  =     (~obj.phase)*(~(Ts(1) > obj.Thi))*(~(Ts(2) < obj.Tlo))*...
                         (min(Ts(2),obj.Thi) - max(Ts(1),obj.Tlo))*obj.flow*obj.heat...
                       + (obj.phase)*...
                         (Ts(2) == obj.Thi && Ts(1) == obj.Tlo)*...
                         (obj.flow*obj.heat);
              % H =      (sensible heat?)*(Ts includes stream?)*(Ts includes stream?)*...
              %          (calculate sensible heat contribution)...
              %        + (phase change?)*...
              %          (Ts includes stream?)*(Ts includes stream?)*...
              %          (phase heat)
            elseif nargin == 2
                H  =     (~obj.phase)*(~(Ts(1) > obj.Thi))*(~(Ts(2) < obj.Tlo))*...
                         (min(Ts(2),obj.Thi) - max(Ts(1),obj.Tlo))*obj.flow*obj.heat...
                       + (obj.phase)*...
                         (Ts(2) == obj.Thi && Ts(1) == obj.Tlo)*...
                         (obj.flow*obj.heat);
              % H =      (sensible heat?)*(Ts includes stream?)*(Ts includes stream?)*...
              %          (calculate sensible heat contribution)...
              %        + (phase change?)*...
              %          (Ts includes stream?)*(Ts includes stream?)*...
              %          (phase heat)
            else
               % always a positive number
               H =   (~obj.phase)*...
                     (obj.Thi - obj.Tlo)*obj.flow*obj.heat...
                   + (obj.phase)*...
                     (obj.flow*obj.heat);
             % H =      (sensible heat?)*...
             %          (calculate sensible heat contribution)...
             %        + (phase change?)*...
             %          (phase heat)
            end
            H = obj.hot*H;  % adjust the sign
                            % hot streams surrender heat (neg #)
                            % cold streams sink heat (pos #)
        end
    end
end