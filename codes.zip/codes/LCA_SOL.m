function [OBJ_SOL] = LCA_SOL(x)
    
    
calc_obj_with_LCA

 OBJ_SOL =  LCA_TOTAL
end

